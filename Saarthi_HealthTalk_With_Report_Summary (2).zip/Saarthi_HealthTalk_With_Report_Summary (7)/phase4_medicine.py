import sqlite3
from datetime import datetime

# Create medicine tables
def create_medicine_tables():

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS medicines(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_name TEXT,
        reminder_time TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS medicine_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_name TEXT,
        reminder_time TEXT,
        status TEXT,
        log_date TEXT
    )
    """)

    conn.commit()
    conn.close()


# Add medicine
def add_medicine(name, reminder_time):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO medicines
        (medicine_name, reminder_time)
        VALUES (?,?)
        """,
        (name, reminder_time)
    )

    conn.commit()
    conn.close()


# Show medicines
def get_medicines():

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM medicines"
    )

    medicines = cursor.fetchall()

    conn.close()

    return medicines


# Delete medicine
def delete_medicine(name):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        DELETE FROM medicines
        WHERE medicine_name=?
        """,
        (name,)
    )

    conn.commit()
    conn.close()


# Update medicine time
def update_medicine_time(
    medicine_name,
    new_time
):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE medicines
        SET reminder_time=?
        WHERE medicine_name=?
        """,
        (
            new_time,
            medicine_name
        )
    )

    conn.commit()
    conn.close()


# Save medicine log
def save_medicine_log(
    medicine_name,
    reminder_time,
    status
):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO medicine_logs
        (
            medicine_name,
            reminder_time,
            status,
            log_date
        )
        VALUES (?,?,?,?)
        """,
        (
            medicine_name,
            reminder_time,
            status,
            datetime.now().strftime(
                "%Y-%m-%d"
            )
        )
    )

    conn.commit()
    conn.close()


# Show medicine history
def get_medicine_history():

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM medicine_logs
        ORDER BY id DESC
        LIMIT 20
        """
    )

    history = cursor.fetchall()

    conn.close()

    return history

# Check if medicine exists
def medicine_exists(name):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT * FROM medicines
        WHERE medicine_name=?
        """,
        (name,)
    )

    result = cursor.fetchone()

    conn.close()

    return result is not None


# Mark medicine as taken
def mark_medicine_taken(name):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT reminder_time
        FROM medicines
        WHERE medicine_name=?
        """,
        (name,)
    )

    medicine = cursor.fetchone()

    if medicine:

        save_medicine_log(
            name,
            medicine[0],
            "Taken"
        )

    conn.close()


# Mark medicine as missed
def mark_medicine_missed(name):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT reminder_time
        FROM medicines
        WHERE medicine_name=?
        """,
        (name,)
    )

    medicine = cursor.fetchone()

    if medicine:

        save_medicine_log(
            name,
            medicine[0],
            "Missed"
        )

    conn.close()


# Get one medicine
def get_medicine(name):

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM medicines
        WHERE medicine_name=?
        """,
        (name,)
    )

    medicine = cursor.fetchone()

    conn.close()

    return medicine


# Get today's medicine report
def get_today_report():

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    today = datetime.now().strftime(
        "%Y-%m-%d"
    )

    cursor.execute(
        """
        SELECT *
        FROM medicine_logs
        WHERE log_date=?
        """,
        (today,)
    )

    report = cursor.fetchall()

    conn.close()

    return report
