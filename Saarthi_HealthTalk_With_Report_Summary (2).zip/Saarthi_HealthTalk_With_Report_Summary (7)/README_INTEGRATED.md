# Saarthi Health AI + HealthTalk — Integrated Prototype

This folder combines the existing Saarthi Flask dashboard and its profile, report, health-history, medicine, safety, hospital and emergency routes with a local HealthTalk medical Q&A engine.

## New dashboard

The main dashboard (`templates/index.html`) has been redesigned as a responsive, light-theme health workspace with sidebar navigation, health metric cards, a chat composer, voice controls, location map panel, emergency-support panel, and visible prototype/safety notices. Existing Flask route names and chat/vitals/location element IDs were preserved where applicable.

## What is integrated

- Saarthi dashboard and existing chat route remain the main interface.
- All chat messages are routed through HealthTalk and the local Ollama model (`llama3.2`); Gemini is not used for chat. HealthTalk retrieves passages from the bundled medical textbook and imported PDFs.
- The dashboard has a Medical Documents panel for importing searchable PDF documents. Uploaded PDFs are stored under `knowledge_documents/` and are searchable on the next question without restarting the app. Scanned/image-only PDFs need OCR first.
- Existing report uploads remain available; automatic report summaries are not generated with Gemini.
- Unwanted avatar images from the old standalone HealthTalk chat are not used in this integrated UI.
- Chat message rendering uses `textContent` instead of inserting user text as HTML.

## Important implementation note

The uploaded HealthTalk ZIP did **not** contain its `faiss_index` directory. To avoid silently depending on a missing index, this integrated version uses a lightweight keyword/IDF text retriever over the included medical PDF. It is a prototype retrieval method, not the original FAISS embedding index. Retrieval quality must be tested; it can return weakly relevant passages.

## Windows setup

1. Make a backup of your current Saarthi and HealthTalk folders and database.
2. Extract this integrated folder to a new location; do not overwrite your originals.
3. Run `setup.bat` once.
4. Start Ollama and ensure the model is installed:
   ```bat
   ollama pull llama3.2
   ollama list
   ```
5. Run `run.bat`.
6. Open `http://127.0.0.1:5000`.

## Configuration

- `.env.example` is a template. Copy it to `.env` and add your own credentials locally.
- The project archive originally included a `.env` file. This output deliberately excludes real credentials. If any real API/Twilio credentials were included in a shared archive, rotate/revoke them.
- For SMS, set `SMS_TWILIO_SID`, `SMS_TWILIO_TOKEN`, `SMS_TWILIO_NUMBER`, and `FAMILY_NUMBER` in `.env`. Use a Twilio SMS-capable sender and international E.164 phone formats such as `+91XXXXXXXXXX`. Trial accounts can only message verified recipients. Restart `run.bat` after editing `.env`; then use **Send test SMS** in the dashboard to see Twilio's actual response.
- WhatsApp requires a configured Twilio WhatsApp sender and an opted-in/allowed recipient. The dashboard status checks configuration, not delivery.
- Ollama must be running locally for all HealthTalk chat. The dashboard's test button can confirm whether Twilio accepts an SMS request; it cannot guarantee carrier delivery or emergency-service response.

## Verification status

- Python syntax compilation: checked for the integrated Python files.
- Medical PDF text extraction and local retrieval: tested in the build environment.
- Python syntax compilation and ZIP integrity: checked. Live Ollama and Twilio delivery still require credentials and a test on your Windows PC. This build has not been verified end-to-end on your machine.

## Medical safety

This is an educational prototype, not a medical device. AI summaries and answers can be wrong. Do not use it to diagnose, prescribe, change medication, or make emergency decisions. Personal reports should be interpreted by a qualified clinician. For emergencies, contact local emergency services directly.


## New feature: AI medical report summary

The dashboard's Medical Documents upload now displays an **AI Medical Report Summary** after a searchable PDF is imported. It extracts the report text and asks the configured local Ollama model (`OLLAMA_MODEL`, default `llama3.2`) to summarise key findings and any values the report itself marks high/low. It does not diagnose or recommend medication changes. If Ollama is unavailable, the upload still succeeds and the dashboard displays a clear summary-generation warning. Scanned PDFs without selectable text still require OCR.
