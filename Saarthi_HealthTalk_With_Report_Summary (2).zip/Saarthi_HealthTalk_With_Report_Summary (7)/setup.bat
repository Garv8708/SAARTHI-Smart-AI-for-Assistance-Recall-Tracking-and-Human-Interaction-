@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3.10 -m venv .venv
  if errorlevel 1 python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Setup complete. Edit .env if you want Gemini or Twilio features.
echo Ensure Ollama is installed and run: ollama pull llama3.2
pause
