from datetime import datetime

# Emergency keywords
EMERGENCY_KEYWORDS = [
    "चक्कर",
    "सीने में दर्द",
    "सांस नहीं",
    "सांस लेने में दिक्कत",
    "बेहोश",
    "गिर गया",
    "मदद",
    "emergency",
    "heart attack",
    "chest pain",
    "dizziness",
    "sos"
]

# Check emergency message
def check_emergency(user_message):

    user_message = user_message.lower()

    for keyword in EMERGENCY_KEYWORDS:

        if keyword.lower() in user_message:

            return True

    return False


# Health emergency check
def check_health_emergency(data):

    alerts = []

    if data["heart_rate"] > 120:
        alerts.append(
            "High Heart Rate"
        )

    if data["spo2"] < 90:
        alerts.append(
            "Low Oxygen Level"
        )

    return alerts


# Emergency log
def create_emergency_log(alert_text):

    with open(
        "emergency_logs.txt",
        "a",
        encoding="utf-8"
    ) as file:

        file.write(
            f"{datetime.now()} : {alert_text}\n"
        )

    print(
        "Emergency Logged:",
        alert_text
    )
