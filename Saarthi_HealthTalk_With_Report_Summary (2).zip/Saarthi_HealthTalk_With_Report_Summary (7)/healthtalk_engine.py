"""Local HealthTalk retrieval + Ollama answer engine for Saarthi.

This module is loaded lazily from Saarthi's /chat route. It uses the supplied
medical textbook PDF and a lightweight local keyword ranker, so the project
works even when the original FAISS index is not present in the supplied ZIP.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from collections import Counter
from functools import lru_cache
from typing import Iterable

import requests
from pypdf import PdfReader

BASE_DIR = Path(__file__).resolve().parent
PDF_PATH = Path(os.getenv("HEALTHTALK_PDF_PATH", str(BASE_DIR / "data" / "Medical_book.pdf")))
UPLOAD_DIR = Path(os.getenv("HEALTHTALK_UPLOAD_DIR", str(BASE_DIR / "knowledge_documents"))).resolve()
UPLOAD_DIR.mkdir(exist_ok=True)
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
MODEL_NAME = os.getenv("OLLAMA_MODEL", "llama3.2")

STOPWORDS = {
    "what", "is", "are", "the", "a", "an", "of", "in", "on", "for", "to", "and", "or", "how", "does", "do", "can", "i", "my", "me", "about", "explain", "tell", "please", "simple", "meaning", "kya", "hai", "hota", "hoti", "ka", "ki", "ke", "ko", "mein", "mujhe", "batao", "samjhao", "kya", "aur", "se", "kaise"
}


def _tokens(text: str) -> list[str]:
    words = re.findall(r"[a-zA-Z]{2,}|[0-9]{2,}|[\u0900-\u097F]{2,}", (text or "").lower())
    return [w for w in words if w not in STOPWORDS]


def _split_text(text: str, page_number: int, chunk_size: int = 1100, overlap: int = 150) -> list[dict]:
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            boundary = text.rfind(". ", start + chunk_size // 2, end)
            if boundary > start:
                end = boundary + 1
        piece = text[start:end].strip()
        if len(piece) > 80:
            chunks.append({"page": page_number, "text": piece, "tokens": Counter(_tokens(piece))})
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def _load_chunks() -> list[dict]:
    """Read the bundled textbook plus user-imported PDFs on each request.

    Cache is intentionally avoided so a newly imported document is available
    to the very next chat message without restarting the app.
    """
    paths = []
    if PDF_PATH.exists():
        paths.append(PDF_PATH)
    if UPLOAD_DIR.exists():
        paths.extend(sorted(UPLOAD_DIR.glob("*.pdf")))
    if not paths:
        raise FileNotFoundError(f"No medical PDFs found. Expected {PDF_PATH} or PDFs in {UPLOAD_DIR}")
    chunks = []
    for path in paths:
        try:
            reader = PdfReader(str(path))
            for page_no, page in enumerate(reader.pages, start=1):
                for chunk in _split_text(page.extract_text() or "", page_no):
                    chunk["document"] = path.name
                    chunks.append(chunk)
        except Exception as exc:
            print(f"HealthTalk could not read {path.name}: {exc}")
    if not chunks:
        raise ValueError("No selectable text could be extracted. Scanned PDFs need OCR before they can be searched.")
    return chunks


def _ollama(prompt: str, timeout: int = 120) -> str:
    response = requests.post(
        OLLAMA_URL,
        json={"model": MODEL_NAME, "prompt": prompt, "stream": False},
        timeout=timeout,
    )
    response.raise_for_status()
    answer = response.json().get("response", "").strip()
    if not answer:
        raise RuntimeError("Ollama returned an empty response.")
    return answer


def _retrieve(question: str, chunks: list[dict], top_k: int = 4) -> list[dict]:
    query_tokens = Counter(_tokens(question))
    if not query_tokens:
        return []
    # Inverse document frequency downweights generic words (e.g. "blood") and
    # gives more weight to topic terms (e.g. "hypertension").
    document_frequency = Counter()
    for chunk in chunks:
        document_frequency.update(set(chunk["tokens"]))
    total = max(1, len(chunks))
    scored = []
    question_lower = (question or "").lower()
    for chunk in chunks:
        overlap = 0.0
        matched = 0
        for token, q_count in query_tokens.items():
            count = chunk["tokens"].get(token, 0)
            if count:
                matched += 1
                idf = 1.0 + __import__("math").log((total + 1) / (document_frequency[token] + 1))
                overlap += min(q_count, count) * idf
        if matched == 0:
            continue
        text_lower = chunk["text"].lower()
        phrase_bonus = 0.0
        # Reward exact clinical phrases when they appear in a passage.
        for phrase in ("high blood pressure", "blood pressure", "hypertension", "diabetes mellitus", "blood sugar"):
            if phrase in question_lower and phrase in text_lower:
                phrase_bonus += 2.5 if phrase in ("high blood pressure", "hypertension", "diabetes mellitus") else 0.8
        coverage = matched / max(1, len(query_tokens))
        score = (overlap / max(1, len(chunk["tokens"]) ** 0.35)) + phrase_bonus + coverage
        scored.append((score, chunk))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [chunk for score, chunk in scored[:top_k] if score > 0]


def ask_medical_question(question: str) -> str:
    """Answer using only the bundled HealthTalk textbook and imported PDFs.

    For report-summary questions, prioritize the user's uploaded report rather
    than unrelated textbook passages. This prevents a generic textbook answer
    when the user asks about "my report" / "meri report".
    """
    chunks = _load_chunks()
    q_lower = (question or "").lower()
    report_intent = any(term in q_lower for term in (
        "my report", "this report", "uploaded report", "medical report", "lab report",
        "test report", "meri report", "report ke baare", "report ke bare", "my uploaded medical report", "uploaded medical report", "my uploaded report",
        "report bata", "report explain", "tell me about my report", "read my report",
        "my test results", "results in my report", "मेरी रिपोर्ट", "रिपोर्ट के बारे",
        "रिपोर्ट समझ", "रिपोर्ट बताओ", "मेरी मेडिकल रिपोर्ट"
    ))
    uploaded_chunks = [c for c in chunks if c.get("document") and c.get("document") != PDF_PATH.name]
    if report_intent and not uploaded_chunks:
        return (
            "I can see the bundled medical textbook, but I cannot find an imported report PDF in "
            f"'{UPLOAD_DIR}'. Please check that the app saves imported reports to this folder "
            "or set HEALTHTALK_UPLOAD_DIR to the folder where the app stores them, then upload "
            "the report again. I will not substitute textbook information for your report values."
        )
    if report_intent and uploaded_chunks:
        # Select the most recently modified imported PDF, rather than relying on
        # alphabetical/list order (which can pick the wrong report).
        uploaded_paths = [p for p in UPLOAD_DIR.glob("*.pdf") if p.is_file()]
        newest_path = max(uploaded_paths, key=lambda p: p.stat().st_mtime, default=None)
        selected_doc = newest_path.name if newest_path else list(dict.fromkeys(c["document"] for c in uploaded_chunks))[-1]
        report_chunks = [c for c in uploaded_chunks if c["document"] == selected_doc]
        if not report_chunks:
            # Fall back to the newest document actually loaded by _load_chunks().
            selected_doc = list(dict.fromkeys(c["document"] for c in uploaded_chunks))[-1]
            report_chunks = [c for c in uploaded_chunks if c["document"] == selected_doc]
        passages = sorted(report_chunks, key=lambda c: c["page"])
        if not passages:
            return (
                "I found imported PDF files, but could not extract searchable text from the selected report. "
                "Try a text-readable PDF; scanned PDFs may require OCR."
            )
        # Include the report's text in page order, up to a safe context limit so
        # values appearing later in a multi-page report are not silently omitted.
        context_parts = []
        context_chars = 0
        for p in passages:
            part = f"[UPLOADED MEDICAL REPORT: {p['document']} | page {p['page']}] {p['text']}"
            if context_chars + len(part) > 18000:
                remaining = 18000 - context_chars
                if remaining > 200:
                    context_parts.append(part[:remaining])
                break
            context_parts.append(part)
            context_chars += len(part) + 2
        context = "\n\n".join(context_parts)
        prompt = f"""You are HealthTalk, a careful medical-document explanation assistant.
Use ONLY the uploaded report text below to extract report-specific results. Do not invent missing values.
List the exact measurement, result, unit, reference range if printed, and whether the report itself flags it high/low. If a value or range is absent, say "not shown in the extracted report text". Explain terms simply; do not diagnose or prescribe.
Do not claim that the user did not upload a report. Do not call a report fictional or a sample unless the report text itself clearly identifies it that way; if it does, say neutrally that the document labels itself as a sample. Do not imply that the report belongs to the user unless the document establishes that.
Answer in the same language/script as the user. If the extracted text does not contain relevant results, say that clearly and ask for a searchable PDF with those results.

UPLOADED REPORT TEXT:\n{context}

USER QUESTION: {question}
"""
        answer = _ollama(prompt)
        pages = sorted({p['page'] for p in passages})
        return f"{answer}\n\nHealthTalk source: {selected_doc}, page(s) {', '.join(map(str, pages))}."

    # Translate/normalize the search query to English for textbook retrieval.
    try:
        search_query = _ollama(
            "Convert this medical question into a short English textbook search query. "
            "Do not answer it or add a new topic. Return only the query.\n\nQuestion: " + question,
            timeout=60,
        )
    except Exception:
        search_query = question

    passages = _retrieve(search_query, chunks) or _retrieve(question, chunks)
    if not passages:
        return (
            "I could not find a sufficiently relevant passage in the supplied medical textbook. "
            "I can't diagnose a condition or recommend a treatment. Please consult a qualified healthcare professional for personal medical advice."
        )

    context = "\n\n".join(f"[Document: {p.get('document', 'Medical textbook')} | page {p['page']}] {p['text']}" for p in passages)
    prompt = f"""You are HealthTalk, an educational medical information assistant integrated into Saarthi.

LANGUAGE:
- Answer in the same language and script as the user's original question.
- English question: English. Hindi in Devanagari: natural Hindi. Hinglish in Latin letters: natural Hinglish in Latin letters.
- Use simple, concise wording and short bullet points where useful.

SAFETY AND ACCURACY:
- Use the supplied textbook passages as the main source. Do not claim unsupported details came from the textbook.
- Do not invent symptoms, causes, test results, diagnoses, or treatments.
- Do not prescribe medicines or change a person's medication.
- If the passages do not answer the question, say that the textbook does not provide enough information.
- Do not imply that common symptoms prove a diagnosis. Explain when a condition can have no obvious symptoms if supported by the passages.
- For personal concerns, recommend a qualified healthcare professional.
- For possible immediate emergencies such as severe chest pain, severe breathing difficulty, or sudden stroke-like symptoms, advise contacting local emergency services immediately.
- End with a brief note that this is educational information, not a diagnosis.

RELEVANT HEALTHTALK DOCUMENT PASSAGES:
{context}

ORIGINAL USER QUESTION:
{question}

Answer only the user's question, in the correct language. If useful, mention the textbook page numbers used."""
    answer = _ollama(prompt)
    sources = sorted({f"{p.get('document', 'Medical textbook')} (page {p['page']})" for p in passages})
    return f"{answer}\n\nHealthTalk sources: {'; '.join(sources)}."
