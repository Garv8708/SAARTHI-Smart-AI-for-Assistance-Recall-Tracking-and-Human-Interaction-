
import requests
import time

def find_nearby_hospitals(lat, lon):

    overpass_url = "https://overpass-api.de/api/interpreter"
    print("USING URL =", overpass_url)

    query = f"""
    [out:json][timeout:15];
    (
      node["amenity"="hospital"](around:10000,{lat},{lon});
      way["amenity"="hospital"](around:10000,{lat},{lon});
      relation["amenity"="hospital"](around:10000,{lat},{lon});
    );
    out center tags;
    """

    headers = {
        "User-Agent": "Saarthi/1.0 (hospital search)"
    }

    # Retry briefly if the public API is temporarily busy
    for attempt in range(2):
        try:
            response = requests.post(
                overpass_url,
                data={"data": query},
                headers=headers,
                timeout=(5, 25)
            )

            print("STATUS =", response.status_code)

            response.raise_for_status()
            data = response.json()

            hospitals = []
            seen = set()

            for hospital in data.get("elements", []):
                tags = hospital.get("tags", {})
                name = tags.get("name", "Unknown Hospital")

                # Avoid duplicate names
                if name not in seen:
                    hospitals.append(name)
                    seen.add(name)

                if len(hospitals) >= 5:
                    break

            return hospitals

        except (requests.RequestException, ValueError) as e:
            print(f"Hospital search failed (attempt {attempt + 1}/2): {e}")

            if attempt == 0:
                time.sleep(2)

    # Return an empty list instead of crashing Saarthi
    return []
