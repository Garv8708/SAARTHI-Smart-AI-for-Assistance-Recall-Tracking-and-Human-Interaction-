import sqlite3
import random
from datetime import datetime
from phase3_emergency import (
    check_health_emergency,
    create_emergency_log
)
def create_health_table():

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS health_data(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        heart_rate INTEGER,

        spo2 INTEGER,

        steps INTEGER,

        timestamp TEXT

    )
    """)

    conn.commit()

    conn.close()
def get_latest_health_data():

    conn = sqlite3.connect("saarthi.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT heart_rate, spo2, steps
        FROM health_data
        ORDER BY id DESC
        LIMIT 1
    """)

    row = cursor.fetchone()

    conn.close()

    if row:
        return {
            "heart_rate": row[0],
            "spo2": row[1],
            "steps": row[2]
        }

    return {
        "heart_rate": 0,
        "spo2": 0,
        "steps": 0
    }

def get_smartwatch_data():

    return {

        "heart_rate":
        random.randint(
            60,
            130
        ),

        "spo2":
        random.randint(
            88,
            100
        ),

        "steps":
        random.randint(
            1000,
            12000
        ),

        "timestamp":
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    }
def save_health_data(data):

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO health_data
        (
            heart_rate,
            spo2,
            steps,
            timestamp
        )
        VALUES (?,?,?,?)
        """,
        (
            data["heart_rate"],
            data["spo2"],
            data["steps"],
            data["timestamp"]
        )
    )

    conn.commit()

    conn.close()

def get_health_history():

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM health_data
        ORDER BY id DESC
        LIMIT 10
        """
    )

    rows = cursor.fetchall()

    conn.close()

    return rows


def monitor_health():

    data = get_smartwatch_data()

    save_health_data(data)

    print(
        "Health Data Saved:",
        data
    )

    alerts = check_health_emergency(data)

    for alert in alerts:

        print(
            "ALERT:",
            alert
        )

        create_emergency_log(
            alert
        )

        # Future SMS alert
        # send_emergency_sms(alert)
