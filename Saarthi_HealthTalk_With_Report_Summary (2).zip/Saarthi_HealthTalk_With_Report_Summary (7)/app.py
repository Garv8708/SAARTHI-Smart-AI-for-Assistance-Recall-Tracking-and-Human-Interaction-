from flask import Flask, render_template, request, jsonify, redirect
from werkzeug.utils import secure_filename
from pypdf import PdfReader
import google.generativeai as genai
from dotenv import load_dotenv
from twilio.rest import Client
import sqlite3
import schedule
import time
import threading
import os
import re
from phase1_profile import (
    create_person_table,
    add_person,
    get_person,
    get_all_persons,
    update_person,
    delete_person,
    person_exists
)
from phase1_reports import (
    create_report_table,
    save_report,
    get_person_reports
)
from phase2_health import (
    create_health_table,
    get_smartwatch_data,
    get_health_history,
    monitor_health,
    get_latest_health_data
)
from phase3_emergency import (
    check_emergency,
    check_health_emergency,
    create_emergency_log
)
from phase4_medicine import (
    create_medicine_tables,
    add_medicine,
    get_medicines,
    delete_medicine,
    update_medicine_time,
    save_medicine_log,
    get_medicine_history,
    mark_medicine_taken,
    get_today_report
)

from phase6_safety import (
    create_safety_table,
    detect_fall,
    check_inactivity,
    get_safety_alerts,
    trigger_sos
)

from phase13_hospital import (
    find_nearby_hospitals
)
    
# Load environment variables
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

app = Flask(__name__)
LATEST_PROFILE_NAME = ""

# Read API key from .env
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    print("INFO: GEMINI_API_KEY not configured; general Gemini chat will be unavailable.")
else:
    genai.configure(api_key=api_key)

USER_PROFILE = {
    "name": "Tarun",
    "age": 70,
    "family_contact": os.getenv("FAMILY_PHONE_NUMBER")
}
current_location = {
    "latitude": None,
    "longitude": None
}

# Twilio Configuration
sms_sid = os.getenv("SMS_TWILIO_SID")
sms_token = os.getenv("SMS_TWILIO_TOKEN")
wa_sid = os.getenv("WHATSAPP_TWILIO_SID")
wa_token = os.getenv("WHATSAPP_TWILIO_TOKEN")
sms_client = Client(sms_sid, sms_token) if sms_sid and sms_token else None
whatsapp_client = Client(wa_sid, wa_token) if wa_sid and wa_token else None

TWILIO_PHONE = os.getenv("SMS_TWILIO_NUMBER")
FAMILY_PHONE = os.getenv("FAMILY_NUMBER")

EMERGENCY_KEYWORDS = [
    # Fall / injury: Hindi and common Hinglish spellings
    "गिर गया", "गिर गई", "गिर गया हूँ", "गिर गयी", "फिसल गया",
    "gir gaya", "gir gayi", "gir gya", "gir gyi", "main gir gaya",
    "fall detected", "i fell", "i have fallen",

    # Serious symptoms: Hindi / Hinglish / English
    "तेज बुखार", "बहुत तेज बुखार", "high fever", "fever is high",
    "very high fever", "fever above 103", "fever above 104",
    "बेहोश", "होश नहीं", "unconscious", "not responding",
    "सांस नहीं आ रही", "सांस लेने में दिक्कत", "saans nahi aa rahi",
    "difficulty breathing", "trouble breathing", "can't breathe",
    "सीने में दर्द", "छाती में दर्द", "chest pain", "severe chest pain",
    "heart attack", "stroke", "दौरा पड़", "seizure",
    "बहुत खून बह", "bleeding heavily", "severe bleeding",
    "बहुत कमजोरी", "severe weakness",

    # General emergency/help
    "मदद", "help", "emergency", "urgent help", "sos", "चक्कर","बहुत ज्यादा खून बहना",
"ज्यादा खून बहना",
"खून बह रहा है",
"मुझे 103 पर बुखार है",
"103 पर बुखार",
"104 पर बुखार",

    # Punjabi
    "ਡਿੱਗ ਗਿਆ", "ਮਦਦ ਕਰੋ", "ਤੇਜ਼ ਬੁਖਾਰ", "ਸਾਹ ਨਹੀਂ ਆ ਰਿਹਾ",
    # Bengali
    "আমি পড়ে গেছি", "বাঁচাও", "খুব জ্বর",
    # Tamil
    "விழுந்துவிட்டேன்", "உதவி", "அதிக காய்ச்சல்",
    # Telugu
    "పడిపోయాను", "సహాయం", "తీవ్రమైన జ్వరం",
    # Marathi
    "मी पडलो", "मदत करा", "खूप ताप",
    # Gujarati
    "હું પડી ગયો", "મદદ કરો", "ખૂબ તાવ"
]

create_health_table()
create_medicine_tables()
create_safety_table()
create_person_table()
create_report_table()

REMINDER_KEYWORDS = [
    "दवाई",
    "medicine",
    "tablet",
    "reminder"
]


def save_medicine(name, time):

    conn = sqlite3.connect("saarthi.db")

    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO medicines
        (medicine_name, reminder_time)
        VALUES (?,?)
        """,
        (name, time)
    )

    conn.commit()
    conn.close()


def medicine_alert():

    print("Time to take your medicine!")


schedule.every().day.at("20:00").do(
    medicine_alert
)

schedule.every(1).minutes.do(
    monitor_health
)

def get_google_maps_link():

    lat = current_location["latitude"]
    lon = current_location["longitude"]

    if lat is None:
        return "Location Not Available"

    return (
        f"https://maps.google.com/?q="
        f"{lat},{lon}"
    )


def scheduler_loop():

    while True:
        schedule.run_pending()
        time.sleep(1)


threading.Thread(
    target=scheduler_loop,
    daemon=True
).start()




def send_emergency_sms(message_text):
    if sms_client is None:
        print("SMS not sent: Twilio SMS credentials are not configured.")
        return False

    try:
        # Current location browser se milti hai
        location = current_location

        if location and location.get("latitude") is not None and location.get("longitude") is not None:
            maps_link = (
                f"https://maps.google.com/?q="
                f"{location['latitude']},{location['longitude']}"
            )
            sms_body = f"SAARTHI SOS: Medical emergency! Call now. Location: {maps_link}"
        else:
            sms_body = "SAARTHI SOS: Medical emergency! Call now. Location unavailable."

        message = sms_client.messages.create(
            body=sms_body,
            from_=os.getenv("SMS_TWILIO_NUMBER"),
            to=os.getenv("FAMILY_NUMBER")
        )

        print("SMS submitted to Twilio. SID:", message.sid)
        print("Initial Twilio status:", message.status)
        return True

    except Exception as e:
        print("SMS Error:", repr(e))
        return False


def send_whatsapp_alert(message_text):

    if whatsapp_client is None:
        print("WhatsApp not sent: Twilio WhatsApp credentials are not configured.")
        return False
    try:

        whatsapp_client.messages.create(
        body=message_text,
        from_=os.getenv("WHATSAPP_TWILIO_NUMBER", 'whatsapp:+14155238886'),
        to=os.getenv("WHATSAPP_NUMBER")
        )


        print(
            "WhatsApp Alert Request Accepted"
        )
        return True

    except Exception as e:
        print("WhatsApp Error:", repr(e))
        return False


# Create Gemini model only when an API key is configured.
model = genai.GenerativeModel("gemini-2.5-flash") if api_key else None
chat_session = model.start_chat(history=[]) if model else None

SYSTEM_PROMPT = """
You are Saarthi.

You are a caring elderly assistant.

Reply in the same language used by the user.

Support all Indian regional languages including:

Hindi
English
Punjabi
Haryanvi
Bengali
Tamil
Telugu
Marathi
Gujarati
Kannada
Malayalam

Keep answers short.

Always be supportive.

Never mention you are Gemini.
"""


# HealthTalk document library: uploaded PDFs become searchable by the local HealthTalk engine.
ALLOWED_MEDICAL_EXTENSIONS = {"pdf"}

@app.route("/medical-documents", methods=["GET", "POST"])
def medical_documents():
    from healthtalk_engine import UPLOAD_DIR
    if request.method == "GET":
        files = sorted([p.name for p in UPLOAD_DIR.glob("*.pdf")])
        return jsonify({"documents": files, "bundled_document": os.path.basename(os.getenv("HEALTHTALK_PDF_PATH", "data/Medical_book.pdf"))})
    uploaded = request.files.get("medical_document")
    if not uploaded or not uploaded.filename:
        return jsonify({"ok": False, "message": "Choose a PDF document first."}), 400
    safe_name = secure_filename(uploaded.filename)
    if os.path.splitext(safe_name)[1].lower() != ".pdf":
        return jsonify({"ok": False, "message": "Only PDF files are supported for searchable medical documents."}), 400
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    stored_name = f"{os.path.splitext(safe_name)[0]}_{int(time.time())}.pdf"
    destination = UPLOAD_DIR / stored_name
    uploaded.save(destination)
    try:
        reader = PdfReader(str(destination))
        extracted_text = "\n".join(page.extract_text() or "" for page in reader.pages).strip()
        if len(extracted_text) < 80:
            destination.unlink(missing_ok=True)
            return jsonify({"ok": False, "message": "This PDF has no selectable text. It may be scanned; run OCR first, then upload the searchable PDF."}), 400
    except Exception as exc:
        destination.unlink(missing_ok=True)
        return jsonify({"ok": False, "message": f"Could not read this PDF: {exc}"}), 400

    # Summarise only the uploaded report's extracted text using the local Ollama model.
    # If Ollama is unavailable, explain that instead of inventing clinical findings.
    summary = "AI summary could not be generated because the local AI model is unavailable. The PDF was imported successfully; start Ollama and try again. This is not a diagnosis."
    try:
        from healthtalk_engine import _ollama
        report_excerpt = extracted_text[:12000]
        prompt = (
            "You are Saarthi, an assistant that explains medical reports in plain language. "
            "Summarise ONLY the supplied report text; do not infer a diagnosis, invent values, or prescribe/change medicines. "
            "Use the same language as the report where practical. Include: (1) key findings and exact values/units if present, "
            "(2) items the report itself marks high/low/abnormal, (3) what the patient can discuss with a qualified clinician. "
            "If reference ranges or units are missing, say they are not shown. Keep it concise and readable. "
            "Clearly say this is an informational summary, not a diagnosis.\n\nREPORT TEXT:\n" + report_excerpt
        )
        generated = _ollama(prompt, timeout=120)
        if generated.strip():
            summary = generated.strip()
    except Exception as exc:
        print(f"Report summary generation unavailable: {exc}")

    return jsonify({
        "ok": True,
        "message": f"Imported {safe_name}. HealthTalk can use it in the next conversation; no restart needed.",
        "summary": summary,
        "filename": safe_name,
        "documents": sorted(p.name for p in UPLOAD_DIR.glob("*.pdf"))
    })

@app.route("/twilio-status")
def twilio_status():
    # Report exactly which configuration fields are missing without exposing secrets.
    required = {
        "SMS_TWILIO_SID": bool(os.getenv("SMS_TWILIO_SID", "").strip()),
        "SMS_TWILIO_TOKEN": bool(os.getenv("SMS_TWILIO_TOKEN", "").strip()),
        "SMS_TWILIO_NUMBER": bool(os.getenv("SMS_TWILIO_NUMBER", "").strip()),
        "FAMILY_NUMBER": bool(os.getenv("FAMILY_NUMBER", "").strip()),
    }
    sms_ready = all(required.values()) and sms_client is not None
    wa_required = {
        "WHATSAPP_TWILIO_SID": bool(os.getenv("WHATSAPP_TWILIO_SID", "").strip()),
        "WHATSAPP_TWILIO_TOKEN": bool(os.getenv("WHATSAPP_TWILIO_TOKEN", "").strip()),
        "WHATSAPP_NUMBER": bool(os.getenv("WHATSAPP_NUMBER", "").strip()),
    }
    wa_ready = all(wa_required.values()) and whatsapp_client is not None
    missing = [key for key, configured in required.items() if not configured]
    return jsonify({"sms_ready": sms_ready, "whatsapp_ready": wa_ready,
        "missing_sms_fields": missing,
        "sms_sender_configured": required["SMS_TWILIO_NUMBER"],
        "sms_recipient_configured": required["FAMILY_NUMBER"],
        "message": ("Missing .env values: " + ", ".join(missing) + ". Save .env and restart run.bat." if missing else "All required SMS settings are present. If sending fails, check Twilio credentials, SMS capability, E.164 numbers, trial verification, and account balance/permissions."),
        "whatsapp_message": ("WhatsApp needs WHATSAPP_TWILIO_SID, WHATSAPP_TWILIO_TOKEN, and WHATSAPP_NUMBER configured; recipient must be WhatsApp-enabled." if not wa_ready else "WhatsApp settings are present; provider approval and recipient eligibility may still apply.")})

@app.route("/send-test-sms", methods=["POST"])
def send_test_sms():
    if not (sms_client and os.getenv("SMS_TWILIO_NUMBER") and os.getenv("FAMILY_NUMBER")):
        return jsonify({"ok": False, "message": "Twilio SMS is not fully configured. Fill SMS_TWILIO_SID, SMS_TWILIO_TOKEN, SMS_TWILIO_NUMBER, and FAMILY_NUMBER in .env, then restart run.bat."}), 400
    try:
        message = sms_client.messages.create(body="Saarthi test SMS: Twilio SMS configuration is working.",
            from_=os.getenv("SMS_TWILIO_NUMBER"), to=os.getenv("FAMILY_NUMBER"))
        return jsonify({"ok": True, "message": f"Twilio accepted the test SMS (status: {message.status}, SID: {message.sid}). Delivery may take a short time."})
    except Exception as exc:
        print("Twilio test SMS error:", repr(exc))
        return jsonify({"ok": False, "message": f"Twilio rejected the test SMS: {exc}. Check the Twilio error code, number format, trial-account verification, and SMS permissions."}), 502

# Home page and dashboard both render the same dashboard template.
def render_dashboard():
    profile_name = LATEST_PROFILE_NAME.strip() or "Health profile"
    return render_template(
        "index.html",
        profile_name=profile_name,
        profile_initial=profile_name[0].upper()
    )


@app.route("/")
def home():
    return render_dashboard()


@app.route("/dashboard")
def dashboard():
    return render_dashboard()



@app.route("/profile", methods=["GET", "POST"])
def profile():
    global LATEST_PROFILE_NAME

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        age = request.form.get("age")
        gender = request.form.get("gender")
        blood_group = request.form.get("blood_group")
        phone = request.form.get("phone")
        emergency_contact = request.form.get("emergency_contact")
        address = request.form.get("address")

        person_id = add_person(
            name,
            age,
            gender,
            blood_group,
            phone,
            emergency_contact,
            address
        )

        LATEST_PROFILE_NAME = name or "Health profile"

        # Open dashboard after creating the profile
        return redirect("/dashboard")

    return render_template("profile.html")

@app.route("/reports/<int:person_id>", methods=["GET", "POST"])
def reports(person_id):

    if not person_exists(person_id):
        return "Person not found", 404

    if request.method == "POST":

        file = request.files.get("report")

        if not file:
            return "No file selected"

        if file.filename == "":
            return "No file selected"

        upload_folder = os.path.join(os.path.dirname(__file__), "uploads")
        os.makedirs(upload_folder, exist_ok=True)
        safe_name = secure_filename(file.filename)
        if not safe_name:
            return "Invalid filename.", 400
        # Avoid overwriting an earlier upload with the same filename.
        base, ext = os.path.splitext(safe_name)
        stored_name = f"{base}_{int(time.time())}{ext}"
        file_path = os.path.join(upload_folder, stored_name)
        file.save(file_path)
        report_type = ext.lstrip(".").lower()
        extracted_text = ""
        ai_summary = ""
        if report_type == "pdf":
            try:
                reader = PdfReader(file_path)
                extracted_text = "\n".join(page.extract_text() or "" for page in reader.pages).strip()
            except Exception:
                extracted_text = ""
        if extracted_text:
            ai_summary = "Report text extracted and saved. For a HealthTalk explanation based on this report, import the PDF in the dashboard's Medical Documents panel. This report is not a diagnosis; ask a clinician to interpret it."
        elif report_type == "pdf":
            ai_summary = "No selectable text was extracted. This may be a scanned PDF; OCR is needed before HealthTalk can search it."
        report_id = save_report(
            person_id, file.filename, file_path, report_type,
            extracted_text=extracted_text, ai_summary=ai_summary
        )
        safe_summary = (ai_summary or "No summary available.").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
        return f"""
        <h2>Medical Report Uploaded</h2>
        <p>Report ID: {report_id}</p><p>File: {safe_name}</p>
        <h3>Summary</h3><p>{safe_summary}</p>
        <p><strong>Important:</strong> AI summaries can be wrong and are not a diagnosis. Ask a qualified clinician to interpret your report.</p>
        <a href="/reports/{person_id}">Upload another report / view reports</a>
        """

    reports_list = get_person_reports(person_id)

    return render_template(
        "reports.html",
        person_id=person_id,
        reports=reports_list
    )

@app.route("/vitals")
def vitals():

    data = get_latest_health_data()

    return jsonify({
        "heart_rate": data["heart_rate"],
        "spo2": data["spo2"],
        "steps": data["steps"]
    })




# General self-care guidance for common, usually mild symptoms.
# This is educational guidance, not diagnosis or a substitute for a clinician.


def detect_high_risk_condition(message):
    text = (message or "").lower().strip()

    # Detect Hindi/Hinglish fever statements with 103/104°F
    fever_context = any(word in text for word in (
        "fever", "bukhar", "बुखार", "ताप"
    ))

    if fever_context:
        # Examples: "103", "103°F", "103 degree"
        match = re.search(
            r"\b(10[3-9](?:\.\d+)?)\s*"
            r"(?:°\s*)?(?:f|fahrenheit|degree|degrees)?\b",
            text
        )
        if match:
            value = float(match.group(1))
            if value >= 103:
                return f"Reported fever of {value:g}°F"

        # Detect very high temperature in Celsius
        match_c = re.search(
            r"\b(3[9-9](?:\.\d+)?|4[0-9](?:\.\d+)?)\s*"
            r"(?:°\s*)?(?:c|celsius)\b",
            text
        )
        if match_c:
            value = float(match_c.group(1))
            if value >= 39.4:
                return f"Reported fever of {value:g}°C"

    urgent_phrases = [
        ("chest pain", "chest pain"),
        ("सीने में दर्द", "सीने में दर्द"),
        ("छाती में दर्द", "छाती में दर्द"),
        ("difficulty breathing", "difficulty breathing"),
        ("trouble breathing", "trouble breathing"),
        ("can't breathe", "difficulty breathing"),
        ("सांस लेने में दिक्कत", "सांस लेने में दिक्कत"),
        ("सांस नहीं आ रही", "सांस लेने में गंभीर दिक्कत"),
        ("unconscious", "unconsciousness"),
        ("बेहोश", "बेहोशी"),
        ("stroke", "possible stroke"),
        ("heart attack", "possible heart attack"),
        ("seizure", "seizure"),
        ("दौरा पड़", "दौरा"),
        ("severe bleeding", "severe bleeding"),
        ("बहुत खून बह", "बहुत ज्यादा खून बहना"),
        ("blue lips", "blue lips"),
        ("suicidal", "self-harm emergency"),
    ]

    for phrase, reason in urgent_phrases:
        if phrase in text:
            return reason

    return None



def get_high_risk_guidance(reason):
    """Immediate safety guidance; never substitutes for emergency medical care."""
    return (
        f"URGENT: {reason} may be serious. Call your local emergency number or seek emergency medical care now. "
        "Do not wait for a chatbot response or rely on home remedies. If chest pain or breathing difficulty is present, "
        "avoid driving yourself; ask someone nearby to help and follow emergency-dispatch instructions. "
        "Saarthi has attempted to alert your family. SMS delivery is not guaranteed, so call them directly too."
    )


def detect_reply_language(message):
    """Choose reply language from the user's message, including common Hinglish."""
    text = (message or "").strip().lower()
    if any("\u0900" <= ch <= "\u097f" for ch in text):
        return "Hindi"
    hinglish_markers = ("mujhe", "hai", "hain", "mera", "meri", "bukhar", "sir dard",
                        "khansi", "sardi", "dard", "gaya", "gayi", "kya", "kaise",
                        "batao", "btao", "ho raha", "ho rahi", "pet", "ulti", "dawai", "dawa")
    if any(marker in text for marker in hinglish_markers):
        return "Hindi/Hinglish"
    return "English"


def localize_self_care_response(message, response):
    """Translate fixed guidance through local Ollama, preserving safety warnings."""
    language = detect_reply_language(message)
    if language == "English":
        return response
    try:
        from healthtalk_engine import _ollama
        prompt = (
            f"Translate the following health guidance into simple natural {language}. "
            "Preserve all numbers, units, and safety warnings. Do not add medical claims, "
            "diagnoses, medicines, or doses. Return only the translation.\n\nTEXT:\n" + response
        )
        translated = _ollama(prompt, timeout=60)
        if translated and translated.strip():
            return translated.strip()
    except Exception as exc:
        print(f"Self-care translation unavailable: {exc}")
    return response + "\n\nHindi translation is temporarily unavailable. Please ensure Ollama is running."


def get_self_care_advice(message):
    text = (message or "").lower()

    advice = [
        (("fever", "bukhar", "बुखार", "ताप"), 
         "For a mild fever: rest, drink water/ORS as appropriate, wear light clothing, and monitor your temperature. Do not start antibiotics or combine fever medicines without a clinician/pharmacist's advice. Seek medical care if fever lasts over 3 days, is around 39.4°C/103°F or higher, or you are getting worse. For a baby under 3 months with 38°C/100.4°F or higher, seek urgent medical care."),
        (("headache", "sir dard", "सिर दर्द", "सिरदर्द"),
         "For a mild headache: drink water, eat if you have skipped a meal, rest in a quiet room, and take a screen break. Ask a pharmacist/clinician before using pain medicine, especially if you have other conditions or take other medicines. Sudden severe headache, weakness, confusion, fainting, stiff neck with fever, or vision/speech problems need urgent medical care."),
        (("common cold", "cold", "sardi", "जुकाम", "सर्दी", "runny nose", "नाक बह"),
         "For a common cold: rest, drink fluids, try saline nasal spray, and use warm drinks for comfort. Honey may soothe a cough for people older than 1 year. Avoid antibiotics unless prescribed. Get medical advice for breathing difficulty, chest pain, dehydration, worsening symptoms, or symptoms lasting more than about 10 days."),
        (("cough", "khansi", "खांसी", "खाँसी"),
         "For a mild cough: drink fluids, try warm drinks, avoid smoke/dust, and consider honey if the person is older than 1 year. Do not give honey to infants under 1 year. Seek care for breathing difficulty, chest pain, blood in sputum, high/persistent fever, or a cough that persists."),
        (("sore throat", "gale mein dard", "गले में दर्द", "गला दर्द"),
         "For a mild sore throat: drink warm or cool fluids, rest your voice, and gargle warm salt water if you can gargle safely. Seek medical advice for difficulty breathing/swallowing, drooling, dehydration, rash, or persistent/worsening symptoms."),
        (("diarrhea", "loose motion", "loose motions", "दस्त", "पेट खराब"),
         "For diarrhea: take frequent small sips of ORS prepared exactly as the packet says, and keep drinking fluids. Seek care for blood/black stool, severe abdominal pain, confusion, very little urine, signs of dehydration, or persistent symptoms. Children, older adults, and medically vulnerable people can become dehydrated quickly."),
        (("constipation", "kabz", "कब्ज"),
         "For mild constipation: drink enough water, gradually increase fibre-rich foods, and take a gentle walk if safe. Do not use laxatives regularly without professional advice. Seek care for severe abdominal pain, vomiting, a swollen abdomen, or inability to pass gas/stool."),
        (("acidity", "heartburn", "gas", "acid reflux", "सीने में जलन", "एसिडिटी"),
         "For occasional acidity: eat smaller meals, avoid lying down for 2–3 hours after eating, and notice/avoid personal trigger foods. Ask a pharmacist/clinician before using antacids, especially if you take other medicines. Chest pressure/pain, breathlessness, sweating, or pain spreading to arm/jaw is an emergency—not something to assume is acidity."),
        (("nausea", "जी मिचलाना", "मतली", "ulti", "vomiting", "उल्टी"),
         "For mild nausea: take small frequent sips of fluid, eat small bland meals if tolerated, and avoid greasy foods. Seek medical care if you cannot keep fluids down, have blood in vomit, severe pain, confusion, or signs of dehydration."),
        (("muscle pain", "body ache", "body pain", "बदन दर्द", "शरीर दर्द"),
         "For mild body aches: rest, drink fluids, and try gentle movement or a warm compress if comfortable. Avoid strenuous activity. Seek medical advice if pain is severe, follows a major injury, comes with high fever/rash/weakness, or does not improve.")
    ]

    for keywords, response in advice:
        if any(keyword in text for keyword in keywords):
            return (
                response
                + "\n\nThis is general self-care information, not a diagnosis. "
                  "If symptoms are severe, unusual, worsening, or you are unsure, contact a qualified healthcare professional."
            )
    return None


# Route educational medical questions to the integrated HealthTalk textbook engine.
MEDICAL_TERMS = (
    "blood pressure", "hypertension", "diabetes", "blood sugar", "fever", "symptom", "symptoms",
    "disease", "medical", "medicine", "medication", "tablet", "pain", "headache", "heart",
    "kidney", "liver", "infection", "report", "lab result", "test result", "cholesterol", "asthma",
    "pregnancy", "health problem", "बीपी", "ब्लड प्रेशर", "शुगर", "बुखार", "लक्षण", "दर्द",
    "दवाई", "दवा", "रिपोर्ट", "बीमारी", "दिल", "किडनी", "खांसी", "सिर दर्द", "स्वास्थ्य समस्या",
    "high bp", "low bp", "spo2", "oxygen level"
)

def is_medical_question(message):
    lowered = (message or "").lower()
    return any(term in lowered for term in MEDICAL_TERMS)


# Chat API
@app.route("/chat", methods=["POST"])
def chat():

    try:

        data = request.get_json()

        if not data:
            return jsonify({
                "response": "No JSON data received"
            }), 400

        user_message = data.get("message")

        if not user_message:
            return jsonify({
                "response": "No message provided"
            }), 400

        print("User:", user_message)

        if (
            "hospital" in user_message.lower()
            or "hospitals" in user_message.lower()
            or "nearby hospital" in user_message.lower()
            or "अस्पताल" in user_message
            ):
            print("HOSPITAL SEARCH TRIGGERED")
            lat = current_location["latitude"]
            lon = current_location["longitude"]
            if lat is None:
                return jsonify({
                    "response":
                    "Location not available."
                    })
            hospitals = find_nearby_hospitals(lat,lon)
            text = "Nearby Hospitals:\n\n"
            for i, hospital in enumerate(hospitals,start=1):
                text += f"{i}. {hospital}\n"
            return jsonify({
                "response": text
                })


       # ==========================
# SOS Alert
# ==========================

        if "sos" in user_message.lower():
            print("CURRENT LOCATION BEFORE SOS =", current_location)
            location_link = get_google_maps_link()
            lat = current_location["latitude"]
            lon = current_location["longitude"]
            hospitals = find_nearby_hospitals(lat, lon) if lat is not None and lon is not None else []
            hospital_text = ""
            for i, hospital in enumerate(hospitals, start=1):
                hospital_link = (
        "https://www.google.com/maps/search/"
        + hospital.replace(" ", "+")
        )
                hospital_text += (
        f"{i}. {hospital}\n"
        f"{hospital_link}\n\n"
        )
            sos_data = trigger_sos(location_link)
            print("SOS LOCATION =", location_link)

            sms_ok = send_emergency_sms(
        f"""
SOS ALERT ACTIVATED

Location:
{sos_data['location']}
"""
    )
            whatsapp_ok = send_whatsapp_alert(
        f"""
SOS ALERT ACTIVATED

Location:
{sos_data['location']}

Nearest Hospitals:
{hospital_text}
"""
    )
            if sms_ok or whatsapp_ok:
                message = "SOS alert request submitted through a configured channel. Please verify delivery."
            else:
                message = "SOS detected, but SMS/WhatsApp alert delivery is not configured. If this is an emergency, call local emergency services now."
            return jsonify({"response": message})

            return jsonify({
        "response":
        f"""
SOS ALERT ACTIVATED

Location:
{sos_data['location']}
"""})

        # ==========================
# Fall Detection
# ==========================

        if detect_fall(user_message):
            print("CURRENT LOCATION =", current_location)
            for i in range(5):
                if current_location["latitude"] is not None:
                    break
                time.sleep(1)
            print("CURRENT LOCATION BEFORE ALERT =", current_location)
            location_link = get_google_maps_link()
            lat = current_location["latitude"]
            lon = current_location["longitude"]
            hospitals = find_nearby_hospitals(lat, lon)
            hospital_text = ""
            for i, hospital in enumerate(hospitals, start=1):
                hospital_link = (
        "https://www.google.com/maps/search/"
        + hospital.replace(" ", "+")
        )
                hospital_text += (
        f"{i}. {hospital}\n"
        f"{hospital_link}\n\n"
        )
            
            print("MAP LINK =", location_link)
            alert_message = f"""
FALL DETECTED

Name: {USER_PROFILE['name']}
Age: {USER_PROFILE['age']}

Location:
{location_link}

Nearest Hospitals:

{hospital_text}

Please contact immediately.
"""
            sms_ok = send_emergency_sms(alert_message)
            whatsapp_ok = send_whatsapp_alert(alert_message)
            alert_status = "परिवार को अलर्ट भेजने का अनुरोध किया गया है। डिलीवरी की पुष्टि करें।" if (sms_ok or whatsapp_ok) else "गिरने की स्थिति हो सकती है, लेकिन SMS/WhatsApp कॉन्फ़िगर नहीं है। तुरंत स्थानीय आपातकालीन सहायता लें।"
            return jsonify({"response": alert_status})

        # Let explicit emergency phrases continue to the SMS/WhatsApp alert handler below.
        # The older check_emergency helper may identify a phrase but does not itself send an alert.
        explicit_emergency_match = any(
            keyword.lower() in user_message.lower()
            for keyword in EMERGENCY_KEYWORDS
        )
        if check_emergency(user_message) and not explicit_emergency_match:
            create_emergency_log(user_message)
            return jsonify({
                "response": "यह आपातकालीन स्थिति हो सकती है। कृपया तुरंत सहायता लें।"
            })

        
        # ==========================
        # Emergency Detection
        # ==========================

        high_risk_reason = detect_high_risk_condition(user_message)
        print("HIGH RISK REASON =", high_risk_reason)
        print("EMERGENCY KEYWORD MATCH =", [
        keyword for keyword in EMERGENCY_KEYWORDS
        if keyword.lower() in user_message.lower()
         ])
        for keyword in EMERGENCY_KEYWORDS:

            if keyword.lower() in user_message.lower() or high_risk_reason:
                print("CURRENT LOCATION =", current_location)
                for i in range(5):
                    if current_location["latitude"] is not None:
                        break
                    time.sleep(1)
                print("CURRENT LOCATION BEFORE ALERT =", current_location)
                location_link = get_google_maps_link()
                print("MAP LINK =", location_link)
                alert_message = f"""
HEALTH EMERGENCY ALERT

Name: {USER_PROFILE['name']}
Age: {USER_PROFILE['age']}
High-risk indicator: {high_risk_reason or 'Emergency keyword detected'}
User message: {user_message}

Location:
{location_link}

This message contains a possible emergency keyword. Please contact the person immediately and verify the situation. If there is immediate danger, contact local emergency services.
"""

                sms_ok = send_emergency_sms(alert_message)
                whatsapp_ok = send_whatsapp_alert(alert_message)
                alert_text = get_high_risk_guidance(high_risk_reason or user_message)
                if not (sms_ok or whatsapp_ok):
                    alert_text += " The app could not submit an alert through the configured SMS/WhatsApp channel."
                alert_text = localize_self_care_response(user_message, alert_text)
                return jsonify({"response": alert_text})

        # Give general self-care guidance for common mild symptoms after emergency checks.
        self_care_advice = get_self_care_advice(user_message)
        if self_care_advice:
            self_care_advice = localize_self_care_response(user_message, self_care_advice)
            return jsonify({"response": self_care_advice, "source": "Saarthi general self-care guidance"})

        # ==========================
        # Show Medicines
        # ==========================

        if "मेरी दवाई" in user_message.lower() or \
    "दवाई दिखाओ" in user_message.lower() or \
    "मुझे दवाई दिखाओ" in user_message.lower() or \
    "show medicines" in user_message.lower():

            medicines = get_medicines()

            if not medicines:

                return jsonify({
                    "response":
                    "कोई दवाई सेव नहीं है।"
                })

            medicine_list = ""

            for medicine in medicines:

                medicine_list += (
                    f"{medicine[1]} - "
                    f"{medicine[2]}\n"
                )

            return jsonify({
                "response":
                "आपकी दवाइयाँ:\n" +
                medicine_list
            })

        # ==========================
        # Delete Medicine
        # ==========================

        if "हटाओ" in user_message:

            medicine_name = (
user_message
.replace("हटाओ", "")
.strip()
)
            delete_medicine(
                medicine_name )
            
            return jsonify({
                "response":
                "दवाई हटा दी गई है।"
            })

        # ==========================
        # Update Medicine Time
        # ==========================

        if "समय बदलो" in user_message:
            medicine_name = (
                user_message
                .replace("समय बदलो", "")
                .strip()
                )
            update_medicine_time(
                medicine_name,
                "21:00"
                )
            return jsonify({
    "response":
    f"{medicine_name} का समय 21:00 कर दिया गया है।"
    })

            # ==========================
# Save Medicine Reminder
# ==========================
        if "दवाई जोड़ो" in user_message:
            medicine_name = (
                user_message
                .replace("दवाई जोड़ो", "")
                .replace("की", "")
                .strip()
                )
            add_medicine(
                medicine_name,
                "20:00"
                )
            print(get_medicines())
            return jsonify({
    "response":
    f"{medicine_name} का रिमाइंडर सेव कर दिया गया है।"
    })

                # ==========================
        # Health Status
        # ==========================

        if (
            "health status" in user_message.lower()
            or "हेल्थ" in user_message
            or "स्वास्थ्य" in user_message
        ):

            print("HEALTH STATUS TRIGGERED")

            data = get_smartwatch_data()

            return jsonify({
                "response":
                f"""
हृदय गति: {data['heart_rate']} BPM
ऑक्सीजन स्तर: {data['spo2']}%
कदम: {data['steps']}
"""
            })
        if "दवाई ले ली" in user_message:
            medicine_name = (
user_message
.replace("दवाई ले ली", "")
.strip())
            mark_medicine_taken(
                medicine_name)
            
            return jsonify({
    "response":
    "बहुत बढ़िया। दवाई लेने का रिकॉर्ड सेव कर दिया गया है।"
            })

        if "दवाई इतिहास" in user_message:
            history = get_medicine_history()
            text = "दवाई इतिहास\n\n"
            for row in history:
                text += (
    f"{row[1]} | "
    f"{row[3]} | "
    f"{row[4]}\n")
            return jsonify({
"response": text})
        
        if "आज की दवाई रिपोर्ट" in user_message:
            report = get_today_report()
            return jsonify({
    "response":
    f"आज कुल {len(report)} दवाई रिकॉर्ड मिले हैं।"
    })

        # ==========================
        # Health History
        # ==========================

        if (
user_message.lower() == "history"
or user_message == "स्वास्थ्य इतिहास" ):

            print("HEALTH HISTORY TRIGGERED")

            history = get_health_history()

            text = "हाल के स्वास्थ्य रिकॉर्ड\n\n"

            for row in history:
                text += (
                    f"हृदय गति:{row[1]} "
                    f"SpO2:{row[2]}% "
                    f"कदम:{row[3]}\n"
                )

            return jsonify({
                "response": text
            })

        

 
        # ==========================
# Safety Alerts
# ==========================

        if "safety alerts" in user_message.lower() or \
            "सुरक्षा अलर्ट" in user_message:

            alerts = get_safety_alerts()

            text = "Safety Alerts\n\n"

            for alert in alerts:

                text += (
        f"{alert[1]} | "
        f"{alert[2]} | "
        f"{alert[3]}\n"
        )
            return jsonify({
                "response": text
                })
        # All conversations use HealthTalk + the local Ollama model and the imported document library.
        # Gemini is deliberately not used for chat.
        try:
            from healthtalk_engine import ask_medical_question
            ai_response = ask_medical_question(user_message)
            reply_language = detect_reply_language(user_message)
            if reply_language != "English":
                try:
                    from healthtalk_engine import _ollama
                    language_prompt = (
                        f"Rewrite the following health information in simple, natural {reply_language}, "
                        "matching the user's language. Preserve medical facts, values, and safety warnings. "
                        "Do not add diagnoses, medicine doses, or new medical advice. Return only the answer.\n\n"
                        f"USER MESSAGE: {user_message}\n\nANSWER: {ai_response}"
                    )
                    localized = _ollama(language_prompt, timeout=60)
                    if localized and localized.strip():
                        ai_response = localized.strip()
                except Exception as language_exc:
                    print(f"HealthTalk language adaptation unavailable: {language_exc}")
            return jsonify({"response": ai_response, "source": "HealthTalk local documents"})
        except Exception as exc:
            print("HealthTalk error:", type(exc).__name__, str(exc))
            return jsonify({"response": (
                "HealthTalk could not answer because its local service or documents are unavailable. "
                "Please make sure Ollama is running, the configured model is installed, and the medical PDF contains selectable text. "
                "Check the Command Prompt for the technical error."
            )}), 503

    except Exception as e:

        print("ERROR:", str(e))

        return jsonify({
            "response": "Sorry, something went wrong. Check the server terminal for details."
        }), 500

@app.route("/health-data")
def health_data():

    data = get_latest_health_data()

    return jsonify({
        "heart_rate": data["heart_rate"],
        "spo2": data["spo2"],
        "steps": data["steps"]
    })

@app.route("/health-history-data")
def health_history_data():

    history = get_health_history()

    labels = []
    heart_rates = []
    spo2_values = []
    steps_values = []

    count = 1

    for row in reversed(history):

        labels.append(f"Record {count}")

        heart_rates.append(row[1])

        spo2_values.append(row[2])

        steps_values.append(row[3])

        count += 1

    return jsonify({

        "labels": labels,

        "heart_rates": heart_rates,

        "spo2": spo2_values,

        "steps": steps_values
    })

@app.route("/update-location", methods=["POST"])
def update_location():

    data = request.json

    print("LOCATION RECEIVED:", data)

    current_location["latitude"] = data["latitude"]
    current_location["longitude"] = data["longitude"]

    print("CURRENT LOCATION:", current_location)

    return jsonify({
        "status": "success"
    })

if __name__ == "__main__":
    # Local prototype only. Do not expose this development server to the internet.
    app.run(host="127.0.0.1", port=5000, debug=False)
