import sqlite3
from datetime import datetime


DATABASE = "saarthi.db"


# ==========================================
# Create Person Profile Table
# ==========================================

def create_person_table():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS persons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            gender TEXT,
            blood_group TEXT,
            phone TEXT,
            emergency_contact TEXT,
            address TEXT,
            created_at TEXT
        )
    """)

    conn.commit()
    conn.close()


# ==========================================
# Add New Person
# ==========================================

def add_person(
    name,
    age,
    gender,
    blood_group,
    phone,
    emergency_contact,
    address
):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO persons (
            name,
            age,
            gender,
            blood_group,
            phone,
            emergency_contact,
            address,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        name,
        age,
        gender,
        blood_group,
        phone,
        emergency_contact,
        address,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    person_id = cursor.lastrowid

    conn.commit()
    conn.close()

    return person_id


# ==========================================
# Get Person by ID
# ==========================================

def get_person(person_id):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM persons
        WHERE id = ?
    """, (person_id,))

    person = cursor.fetchone()

    conn.close()

    return person


# ==========================================
# Get All Persons
# ==========================================

def get_all_persons():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM persons
        ORDER BY id DESC
    """)

    persons = cursor.fetchall()

    conn.close()

    return persons


# ==========================================
# Update Person
# ==========================================

def update_person(
    person_id,
    name,
    age,
    gender,
    blood_group,
    phone,
    emergency_contact,
    address
):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE persons
        SET
            name = ?,
            age = ?,
            gender = ?,
            blood_group = ?,
            phone = ?,
            emergency_contact = ?,
            address = ?
        WHERE id = ?
    """, (
        name,
        age,
        gender,
        blood_group,
        phone,
        emergency_contact,
        address,
        person_id
    ))

    conn.commit()
    conn.close()


# ==========================================
# Delete Person
# ==========================================

def delete_person(person_id):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        DELETE FROM persons
        WHERE id = ?
    """, (person_id,))

    conn.commit()
    conn.close()


# ==========================================
# Check Person Exists
# ==========================================

def person_exists(person_id):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id
        FROM persons
        WHERE id = ?
    """, (person_id,))

    result = cursor.fetchone()

    conn.close()

    return result is not None