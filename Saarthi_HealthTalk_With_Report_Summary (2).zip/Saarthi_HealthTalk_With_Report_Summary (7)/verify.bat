@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run setup.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m py_compile app.py healthtalk_engine.py phase1_profile.py phase1_reports.py phase2_health.py phase3_emergency.py phase4_medicine.py phase6_safety.py phase13_hospital.py
if errorlevel 1 (
  echo Syntax check FAILED.
  pause
  exit /b 1
)
echo Python syntax check PASSED.
.venv\Scripts\python.exe -c "from pypdf import PdfReader; from pathlib import Path; p=Path('data/Medical_book.pdf'); print('Medical PDF exists:', p.exists()); print('Medical PDF pages:', len(PdfReader(str(p)).pages) if p.exists() else 0)"
pause
