import sqlite3
from datetime import datetime


# Create emergency safety table
def create_safety_table():

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS safety_alerts(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        alert_type TEXT,

        message TEXT,

        timestamp TEXT
    )
    """)

    conn.commit()
    conn.close()


# Save safety alert
def save_safety_alert(
    alert_type,
    message
):

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO safety_alerts
        (
            alert_type,
            message,
            timestamp
        )
        VALUES (?,?,?)
        """,
        (
            alert_type,
            message,
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        )
    )

    conn.commit()
    conn.close()


# Fall detection
def detect_fall(user_message):

    fall_keywords = [

        "गिर गया",
        "मैं गिर गया",
        "fell down",
        "fall",
        "help",
        "चोट लग गई"
    ]

    for keyword in fall_keywords:

        if keyword.lower() in user_message.lower():

            save_safety_alert(
                "FALL DETECTED",
                user_message
            )

            return True

    return False


# Inactivity detection simulation
def check_inactivity(hours):

    if hours >= 5:

        save_safety_alert(
            "INACTIVITY ALERT",
            f"No activity detected for {hours} hours"
        )

        return True

    return False


# Get safety alerts
def get_safety_alerts():

    conn = sqlite3.connect(
        "saarthi.db"
    )

    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM safety_alerts
        ORDER BY id DESC
        LIMIT 20
        """
    )

    alerts = cursor.fetchall()

    conn.close()

    return alerts




def trigger_sos(location_link):

    save_safety_alert(
        "SOS ALERT",
        location_link
    )

    return {
        "message": "SOS alert activated",
        "location": location_link
    }
