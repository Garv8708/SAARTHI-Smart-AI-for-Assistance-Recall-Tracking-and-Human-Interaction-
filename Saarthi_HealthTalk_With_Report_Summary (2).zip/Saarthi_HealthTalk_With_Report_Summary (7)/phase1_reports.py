import sqlite3
from datetime import datetime


DATABASE = "saarthi.db"


# ==========================================
# Create Medical Reports Table
# ==========================================

def create_report_table():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS medical_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            file_path TEXT NOT NULL,
            report_type TEXT,
            extracted_text TEXT,
            ai_summary TEXT,
            uploaded_at TEXT
        )
    """)

    conn.commit()
    conn.close()


# ==========================================
# Save Medical Report Information
# ==========================================

def save_report(
    person_id,
    filename,
    file_path,
    report_type,
    extracted_text="",
    ai_summary=""
):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO medical_reports (
            person_id,
            filename,
            file_path,
            report_type,
            extracted_text,
            ai_summary,
            uploaded_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        person_id,
        filename,
        file_path,
        report_type,
        extracted_text,
        ai_summary,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    report_id = cursor.lastrowid

    conn.commit()
    conn.close()

    return report_id


# ==========================================
# Get Reports of One Person
# ==========================================

def get_person_reports(person_id):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM medical_reports
        WHERE person_id = ?
        ORDER BY id DESC
    """, (person_id,))

    reports = cursor.fetchall()

    conn.close()

    return reports